//
//  popcornApp.swift
//  popcorn
//
//  Created by User15 on 2020/9/30.
//

import SwiftUI

@main
struct popcornApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
