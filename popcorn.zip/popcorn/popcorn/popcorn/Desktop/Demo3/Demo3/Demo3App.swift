//
//  Demo3App.swift
//  Demo3
//
//  Created by User11 on 2020/9/23.
//

import SwiftUI

@main
struct Demo3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
