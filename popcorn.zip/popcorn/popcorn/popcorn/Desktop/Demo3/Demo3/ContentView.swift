//
//  ContentView.swift
//  Demo3
//
//  Created by User11 on 2020/9/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            //teeth
            Path{(path)in
                path.move(to: CGPoint(x:525*0.4, y:560*0.4))
                path.addLine(to: CGPoint(x:535*0.4, y:528*0.4))
                path.addLine(to: CGPoint(x:436*0.4, y:512*0.4))
                path.addLine(to: CGPoint(x:436*0.4, y:560*0.4))
                path.closeSubpath()
            }
            .fill(Color(red: 1, green: 1, blue: 1))
            
            Path{(path)in
                //head
                path.move(to: CGPoint(x:415*0.4, y:473*0.4))
                path.addLine(to: CGPoint(x:334*0.4, y:236*0.4))
                //hair
                path.addLine(to: CGPoint(x:359*0.4, y:245*0.4))
                path.addLine(to: CGPoint(x:361*0.4, y:216*0.4))
                path.addLine(to: CGPoint(x:381*0.4, y:230*0.4))
                path.addLine(to: CGPoint(x:386*0.4, y:203*0.4))
                path.addLine(to: CGPoint(x:406*0.4, y:215*0.4))
                path.addLine(to: CGPoint(x:414*0.4, y:191*0.4))
                path.addLine(to: CGPoint(x:438*0.4, y:206*0.4))
                path.addLine(to: CGPoint(x:445*0.4, y:178*0.4))
                path.addLine(to: CGPoint(x:468*0.4, y:200*0.4))
                path.addLine(to: CGPoint(x:477*0.4, y:172*0.4))
                path.addLine(to: CGPoint(x:498*0.4, y:190*0.4))
                path.addLine(to: CGPoint(x:509*0.4, y:168*0.4))
                path.addLine(to: CGPoint(x:525*0.4, y:190*0.4))
                path.addLine(to: CGPoint(x:538*0.4, y:168*0.4))
                path.addLine(to: CGPoint(x:549*0.4, y:191*0.4))
                path.addLine(to: CGPoint(x:568*0.4, y:170*0.4))
                //forehead
                path.addLine(to: CGPoint(x:599*0.4, y:307*0.4))
                path.addQuadCurve(to: CGPoint(x: 612*0.4, y: 336*0.4), control: CGPoint(x: 620*0.4, y: 317*0.4))
                //mouth
                path.addLine(to: CGPoint(x:623*0.4, y:421*0.4))
                path.addLine(to: CGPoint(x:640*0.4, y:466*0.4))
                path.addQuadCurve(to: CGPoint(x: 452*0.4, y: 519*0.4), control: CGPoint(x: 690*0.4, y: 550*0.4))
                path.addQuadCurve(to: CGPoint(x: 525*0.4, y: 560*0.4), control: CGPoint(x: 420*0.4, y: 540*0.4))
                //neck
                path.addLine(to: CGPoint(x:528*0.4, y:553*0.4))
                path.addCurve(to: CGPoint(x: 518*0.4, y: 576*0.4), control1: CGPoint(x: 540*0.4, y: 555*0.4), control2: CGPoint(x: 540*0.4, y: 575*0.4))
                path.addQuadCurve(to: CGPoint(x: 525*0.4, y: 575*0.4), control: CGPoint(x: 524*0.4, y: 575*0.4))
                path.addLine(to: CGPoint(x:523*0.4, y:592*0.4))
                path.addQuadCurve(to: CGPoint(x: 420*0.4, y: 577*0.4), control: CGPoint(x: 470*0.4, y: 610*0.4))
                path.addLine(to: CGPoint(x:422*0.4, y:518*0.4))
                path.closeSubpath()
            }
            .fill(Color(red: 255/255, green: 217/255, blue: 14/255))
            
            //right eye
            Path{(path)in
                path.move(to: CGPoint(x:495*0.4, y:348*0.4))
                path.addQuadCurve(to: CGPoint(x: 444*0.4, y: 410*0.4), control: CGPoint(x: 440*0.4, y: 360*0.4))
                path.addQuadCurve(to: CGPoint(x: 500*0.4, y: 453*0.4), control: CGPoint(x: 454*0.4, y: 451*0.4))
                path.addQuadCurve(to: CGPoint(x: 560*0.4, y: 389*0.4), control: CGPoint(x: 570*0.4, y: 450*0.4))
                path.addQuadCurve(to: CGPoint(x: 495*0.4, y: 348*0.4), control: CGPoint(x: 540*0.4, y: 340*0.4))
            }
            .fill(Color(red: 1, green: 1, blue: 1))
            
            //left eye
            Path{(path)in
                path.move(to: CGPoint(x:616*0.4, y:425*0.4))
                path.addQuadCurve(to: CGPoint(x: 640*0.4, y: 372*0.4), control: CGPoint(x: 645*0.4, y: 410*0.4))
                path.addQuadCurve(to: CGPoint(x: 590*0.4, y: 334*0.4), control: CGPoint(x: 630*0.4, y: 330*0.4))
                path.addQuadCurve(to: CGPoint(x: 542*0.4, y: 365*0.4), control: CGPoint(x: 555*0.4, y: 335*0.4))
                path.addQuadCurve(to: CGPoint(x: 616*0.4, y: 425*0.4), control: CGPoint(x: 535*0.4, y: 435*0.4))
            }
            .fill(Color(red: 1, green: 1, blue: 1))
            
            //nose
            Path{(path)in
                path.move(to: CGPoint(x:556*0.4, y:417*0.4))
                path.addQuadCurve(to: CGPoint(x: 594*0.4, y: 411*0.4), control: CGPoint(x: 563*0.4, y: 422*0.4))
                path.addCurve(to: CGPoint(x: 615*0.4, y: 445*0.4), control1: CGPoint(x: 620*0.4, y: 408*0.4), control2: CGPoint(x: 620*0.4, y: 438*0.4))
                path.addQuadCurve(to: CGPoint(x: 583*0.4, y: 460*0.4), control: CGPoint(x: 610*0.4, y: 455*0.4))
            }
            .fill(Color(red: 255/255, green: 217/255, blue: 14/255))
            
            //ear
            Path{(path)in
                path.move(to: CGPoint(x:435*0.4, y:477*0.4))
                path.addCurve(to: CGPoint(x: 436*0.4, y: 512*0.4), control1: CGPoint(x: 380*0.4, y: 450*0.4), control2: CGPoint(x: 400*0.4, y: 540*0.4))
                path.move(to: CGPoint(x:412*0.4, y:490*0.4))
                path.addQuadCurve(to: CGPoint(x: 430*0.4, y: 501*0.4), control: CGPoint(x: 428*0.4, y: 485*0.4))
                path.move(to: CGPoint(x:416*0.4, y:501*0.4))
                path.addQuadCurve(to: CGPoint(x: 424*0.4, y: 490*0.4), control: CGPoint(x: 415*0.4, y: 490*0.4))
            }
            .fill(Color(red: 255/255, green: 217/255, blue: 14/255))
            
            //black line
            Group{
                Path{(path)in
                    //head
                    path.move(to: CGPoint(x:415*0.4, y:473*0.4))
                    path.addLine(to: CGPoint(x:334*0.4, y:236*0.4))
                    //hair
                    path.addLine(to: CGPoint(x:359*0.4, y:245*0.4))
                    path.addLine(to: CGPoint(x:361*0.4, y:216*0.4))
                    path.addLine(to: CGPoint(x:381*0.4, y:230*0.4))
                    path.addLine(to: CGPoint(x:386*0.4, y:203*0.4))
                    path.addLine(to: CGPoint(x:406*0.4, y:215*0.4))
                    path.addLine(to: CGPoint(x:414*0.4, y:191*0.4))
                    path.addLine(to: CGPoint(x:438*0.4, y:206*0.4))
                    path.addLine(to: CGPoint(x:445*0.4, y:178*0.4))
                    path.addLine(to: CGPoint(x:468*0.4, y:200*0.4))
                    path.addLine(to: CGPoint(x:477*0.4, y:172*0.4))
                    path.addLine(to: CGPoint(x:498*0.4, y:190*0.4))
                    path.addLine(to: CGPoint(x:509*0.4, y:168*0.4))
                    path.addLine(to: CGPoint(x:525*0.4, y:190*0.4))
                    path.addLine(to: CGPoint(x:538*0.4, y:168*0.4))
                    path.addLine(to: CGPoint(x:549*0.4, y:191*0.4))
                    path.addLine(to: CGPoint(x:568*0.4, y:170*0.4))
                    //forehead
                    path.addLine(to: CGPoint(x:599*0.4, y:307*0.4))
                    path.addQuadCurve(to: CGPoint(x: 612*0.4, y: 336*0.4), control: CGPoint(x: 620*0.4, y: 317*0.4))
                    //mouth
                    path.move(to: CGPoint(x: 623*0.4, y: 421*0.4))
                    path.addLine(to: CGPoint(x:640*0.4, y:466*0.4))
                    path.addQuadCurve(to: CGPoint(x: 452*0.4, y: 519*0.4), control: CGPoint(x: 690*0.4, y: 550*0.4))
                    path.addQuadCurve(to: CGPoint(x: 525*0.4, y: 560*0.4), control: CGPoint(x: 420*0.4, y: 540*0.4))
                    //neck
                    path.addLine(to: CGPoint(x:528*0.4, y:553*0.4))
                    path.addCurve(to: CGPoint(x: 518*0.4, y: 576*0.4), control1: CGPoint(x: 540*0.4, y: 555*0.4), control2: CGPoint(x: 540*0.4, y: 575*0.4))
                    path.addQuadCurve(to: CGPoint(x: 525*0.4, y: 575*0.4), control: CGPoint(x: 524*0.4, y: 575*0.4))
                    path.addLine(to: CGPoint(x:523*0.4, y:592*0.4))
                    path.addQuadCurve(to: CGPoint(x: 420*0.4, y: 577*0.4), control: CGPoint(x: 470*0.4, y: 610*0.4))
                    path.addLine(to: CGPoint(x:422*0.4, y:515*0.4))
                    //teeth
                    
                    path.move(to: CGPoint(x:525*0.4, y:560*0.4))
                    path.addLine(to: CGPoint(x:535*0.4, y:528*0.4))
                    path.move(to: CGPoint(x:510*0.4, y:557*0.4))
                    path.addLine(to: CGPoint(x:515*0.4, y:527*0.4))
                    path.move(to: CGPoint(x:485*0.4, y:550*0.4))
                    path.addLine(to: CGPoint(x:488*0.4, y:522*0.4))
                    path.move(to: CGPoint(x:460*0.4, y:543*0.4))
                    path.addLine(to: CGPoint(x:462*0.4, y:520*0.4))
                    //ear
                    path.move(to: CGPoint(x:435*0.4, y:477*0.4))
                    path.addCurve(to: CGPoint(x: 436*0.4, y: 512*0.4), control1: CGPoint(x: 380*0.4, y: 450*0.4), control2: CGPoint(x: 400*0.4, y: 540*0.4))
                    path.move(to: CGPoint(x:412*0.4, y:490*0.4))
                    path.addQuadCurve(to: CGPoint(x: 430*0.4, y: 501*0.4), control: CGPoint(x: 428*0.4, y: 485*0.4))
                    path.move(to: CGPoint(x:416*0.4, y:501*0.4))
                    path.addQuadCurve(to: CGPoint(x: 424*0.4, y: 490*0.4), control: CGPoint(x: 415*0.4, y: 490*0.4))
                    //left eye
                    path.move(to: CGPoint(x:616*0.4, y:425*0.4))
                    path.addQuadCurve(to: CGPoint(x: 640*0.4, y: 372*0.4), control: CGPoint(x: 645*0.4, y: 410*0.4))
                    path.addQuadCurve(to: CGPoint(x: 590*0.4, y: 334*0.4), control: CGPoint(x: 630*0.4, y: 330*0.4))
                    path.addQuadCurve(to: CGPoint(x: 545*0.4, y: 365*0.4), control: CGPoint(x: 555*0.4, y: 335*0.4))
                    //right eye
                    path.move(to: CGPoint(x:495*0.4, y:348*0.4))
                    path.addQuadCurve(to: CGPoint(x: 444*0.4, y: 410*0.4), control: CGPoint(x: 440*0.4, y: 360*0.4))
                    path.addQuadCurve(to: CGPoint(x: 500*0.4, y: 453*0.4), control: CGPoint(x: 454*0.4, y: 451*0.4))
                    path.addQuadCurve(to: CGPoint(x: 560*0.4, y: 389*0.4), control: CGPoint(x: 570*0.4, y: 450*0.4))
                    path.addQuadCurve(to: CGPoint(x: 495*0.4, y: 348*0.4), control: CGPoint(x: 540*0.4, y: 340*0.4))
                    //nose
                    path.move(to: CGPoint(x:561*0.4, y:417*0.4))
                    path.addQuadCurve(to: CGPoint(x: 594*0.4, y: 411*0.4), control: CGPoint(x: 563*0.4, y: 422*0.4))
                    path.addCurve(to: CGPoint(x: 615*0.4, y: 445*0.4), control1: CGPoint(x: 620*0.4, y: 408*0.4), control2: CGPoint(x: 620*0.4, y: 438*0.4))
                    path.addQuadCurve(to: CGPoint(x: 583*0.4, y: 460*0.4), control: CGPoint(x: 610*0.4, y: 455*0.4))
                }
                .stroke(lineWidth: 2)
            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
            ContentView()
        }
    }
}
