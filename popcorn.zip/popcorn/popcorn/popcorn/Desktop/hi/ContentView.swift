//
//  ContentView.swift
//  hi
//
//  Created by User15 on 2020/9/16.
//  Copyright © 2020 test. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello 00857202")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
