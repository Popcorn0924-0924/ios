#include <iostream>
using namespace std;

int main()
{
    int array[100000];

    int i = 0;

    while(cin >> array[i])
    {
        i++;
    }

    for(int j = 0; j < i ; j++)
    {
        cout << array[j] << " ";
    }cout << endl;

    return 0;
}